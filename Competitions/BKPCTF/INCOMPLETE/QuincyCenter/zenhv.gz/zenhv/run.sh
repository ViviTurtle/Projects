#!/bin/sh

cd tz
./tz
